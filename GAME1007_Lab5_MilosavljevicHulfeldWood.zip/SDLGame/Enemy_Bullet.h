#pragma once
#include "Sprite.h"

class Enemy_Bullet : public Sprite 
{
public:
	Enemy_Bullet(SDL_Renderer* renderer);
};

